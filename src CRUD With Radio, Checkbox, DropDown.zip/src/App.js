import { Route, Routes } from "react-router-dom";
import AboutUs from "./NavComponent/AboutUs";
import ContactUs from "./NavComponent/ContactUs";
import EditUser from "./NavComponent/EditUserCompo";
import Error from "./NavComponent/Error";
import Home from "./NavComponent/Home";
import NavBar from "./NavComponent/Navbar"
import Service from "./NavComponent/Services";
import UserDetail from "./NavComponent/UserDetails";
import User from "./NavComponent/Users";

const MyApp=()=>{

    return (<>
        <NavBar/>
        <Routes>
            <Route path="/" element={<Home/>}></Route>
            <Route path="/home" element={<Home/>}></Route>
            <Route path="/about" element={<AboutUs/>}></Route>
            <Route path="/service" element={<Service/>}></Route>
            <Route path="/user" element={<User/>}></Route>
            <Route path="/userDetail" element={<UserDetail/>}></Route>
            <Route path="/contact" element={<ContactUs/>}></Route>
            <Route path="/editUser/:id" element={<EditUser/>}></Route>
            <Route path="/*" element={<Error/>}></Route>
        </Routes>
    </>)
}
export default MyApp;