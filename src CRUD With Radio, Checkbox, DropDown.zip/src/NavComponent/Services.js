
const Service=()=>{
    return (<>
        <h1>This is Service Component</h1>
    </>)
}
export default Service;