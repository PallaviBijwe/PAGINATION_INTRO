import axios from "axios"

let url="http://127.0.0.1:3003/user";

export const registerData=(userObj)=>{
    return axios.post(url,userObj);
}

export const getAllData=()=>{
    return axios.get(url);
}

export const userDelete=(userId)=>{
    return axios.delete(url+"/"+userId);
}

export const getUserDetails=(userId)=>{
    return axios.get(url+"/"+userId)
}

export const updatedUserData=(userUpdatedObj)=>{
    return axios.put(url+"/"+userUpdatedObj.id,userUpdatedObj)
}