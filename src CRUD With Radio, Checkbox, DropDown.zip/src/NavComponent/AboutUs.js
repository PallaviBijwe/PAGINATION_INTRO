
const AboutUs=()=>{
    return (<>
        <h1>This is About Us Component</h1>
    </>)
}
export default AboutUs;