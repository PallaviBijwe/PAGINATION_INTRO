
const ContactUs=()=>{
    return (<>
        <h1>This is Contact Us Component</h1>
    </>)
}
export default ContactUs;