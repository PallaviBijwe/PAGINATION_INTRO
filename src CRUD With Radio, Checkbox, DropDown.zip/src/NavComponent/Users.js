import { useForm } from "react-hook-form";
import { registerData } from "../Service/DataService";

const User=()=>{ 
    const {register,handleSubmit}=useForm();

    const getUserData=(Data)=>{
        console.log(Data);  
        registerData(Data); 
     }
     
    return (<>
        <div className="container-fluid">
            <div className="row" style={{width:'25%',margin:'2%'}}>
                <h2 className="text-primary">Registration Form</h2>
                <form onSubmit={handleSubmit(getUserData)}>        
                    <div className="row" style={{marginTop:'20px'}}>
                        <input type="text" {...register("fname")} className="form-control" placeholder="First name" />
                    </div>
                    <div className="row" style={{marginTop:'20px'}}>
                        <input type="text" {...register("lname")} className="form-control" placeholder="Last name" />
                    </div>  
                    <div className="row" style={{marginTop:'20px'}}>
                        <input type="text" {...register("mobile")} className="form-control" placeholder="Mobile" />
                    </div>
                    <div className="row" style={{marginTop:'20px'}}>
                        <input type="text" {...register("city")} className="form-control" placeholder="City" />
                    </div> 
                    <div className="row" style={{marginTop:'20px'}}>
                        <input type="text" {...register("uname")} className="form-control" placeholder="Username" />
                    </div>
                    <div className="row" style={{marginTop:'20px'}}>
                        <input type="text" {...register("pass")} className="form-control" placeholder="Password" />
                    </div>
                   
                <div style={{marginTop:'20px'}}>
                    <div className="form-check form-check-inline">
                        <input className="form-check-input" type="radio" {...register("gender")} value="Male" />Male  
                    </div>
                    <div className="form-check form-check-inline">
                        <input className="form-check-input" type="radio" {...register("gender")} value="Female" />Female  
                    </div>
                    <div className="form-check form-check-inline">
                        <input className="form-check-input" type="radio" {...register("gender")} value="Transgender" />Transgender 
                    </div>
                </div>

                <div style={{marginTop:'20px'}}>
                    <div className="form-check form-check-inline">
                        <input className="form-check-input" type="checkbox" {...register("lang")} value="Marathi " />Marathi  
                    </div>
                    <div className="form-check form-check-inline">
                        <input className="form-check-input" type="checkbox" {...register("lang")} value="Hindi " />Hindi   
                    </div>
                    <div className="form-check form-check-inline">
                        <input className="form-check-input" type="checkbox" {...register("lang")} value="English " />English 
                    </div>
                </div>
                <div className="row" style={{marginTop:'20px'}}>
                        <select {...register("course")} className="form-select">
                            <option value="NA">Select Course</option>
                            <option value="Python">Python</option>
                            <option value="Java">Java</option>
                            <option value="Angular">Angular</option>
                            <option value="React">React</option>
                        </select>
                </div>
                    <div className="row" style={{marginTop:'20px'}}>
                        <input type="submit" className="btn btn-success" />
                    </div>    
                </form>
            </div>
        </div>
    </>)
}
export default User;