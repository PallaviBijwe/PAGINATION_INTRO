import { NavLink } from "react-router-dom";

const NavBar=()=>{
    return (<>
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
    <div className="container-fluid">
        <div className="collapse navbar-collapse" id="navbarNav">
        <ul className="navbar-nav">
        <li className="nav-item">
            <NavLink to="home" className="nav-link">Home </NavLink>
        </li>
        <li className="nav-item">
            <NavLink to="about" className="nav-link">About Us </NavLink>
        </li>
        <li className="nav-item">
            <NavLink to="service" className="nav-link">Service </NavLink>
        </li>
        <li className="nav-item">
            <NavLink to="user" className="nav-link">User </NavLink>
        </li>
        <li className="nav-item">
            <NavLink to="userDetail" className="nav-link">User Details </NavLink>
        </li>
        <li className="nav-item">
            <NavLink to="contact" className="nav-link">Contact US </NavLink>
        </li>
        </ul>
        </div>
    </div>
    </nav>
    </>)
}
export default NavBar;