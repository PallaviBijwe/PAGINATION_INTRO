import { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import { getAllData, userDelete } from "../Service/DataService";

const UserDetail=()=>{

    const [userList,setUserList]=useState([]);

    const getAllDataFromDB=async()=>{
       const uList=await getAllData();
       console.log(uList.data);
       return setUserList(uList.data);
    }

    useEffect(()=>{
        getAllDataFromDB();
    },[])

    const deleteUser=(userId)=>{
        alert("User Deleted for This id : "+userId);
        userDelete(userId);
    }

    return (<>
            <h1>User Details</h1>
            <div className="container-fluid" style={{width:'90%',margin:'2%'}}>
            <table className="table table-dark">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">First Name</th>
                        <th scope="col">Last Name</th>
                        <th scope="col">Mobile</th>
                        <th scope="col">City</th>
                        <th scope="col">UserName</th>
                        <th scope="col">Password</th>
                        <th scope="col">Gender</th>
                        <th scope="col">Language</th>
                        <th scope="col">Course</th>
                        <th scope="col">Edit</th>
                        <th scope="col">Delete</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        userList.map((user)=>{
                            return (<>
                                    <tr className="table-light">
                                        <td>{user.id}</td>
                                        <td>{user.fname}</td>
                                        <td>{user.lname}</td>
                                        <td>{user.mobile}</td>
                                        <td>{user.city}</td>
                                        <td>{user.uname}</td>
                                        <td>{user.pass}</td>
                                        <td>{user.gender}</td>
                                        <td>{user.lang}</td>
                                        <td>{user.course}</td>
                                        <td>
                                            <NavLink to={`/editUser/${user.id}`}>
                                                <i className="bi bi-pencil-square text-primary"></i>
                                            </NavLink>
                                        </td>
                                        <td><i className="bi bi-trash text-danger" onClick={()=>{deleteUser(user.id)}}></i></td>
                                    </tr>
                            </>)
                        })
                    }                  
                </tbody>
            </table>
            </div>
    </>)
}
export default UserDetail;