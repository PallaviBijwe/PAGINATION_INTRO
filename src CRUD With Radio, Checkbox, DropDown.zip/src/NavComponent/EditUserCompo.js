import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate, useParams } from "react-router-dom";
import { getUserDetails, updatedUserData } from "../Service/DataService";

const EditUser=()=>{
    //useParams use to access the parameter of the current Route /:id
    const {id}=useParams("id"); 

    const [edit,setEditUser]=useState({});

    useEffect(()=>{
        getEditUser();
    },[])

    const getEditUser=async()=>{
        const user=await getUserDetails(id);
        setEditUser(user.data);
    }

    const {register,handleSubmit,setValue}=useForm();
    const navi=useNavigate();

    const getUpdatedUserData=(Data)=>{
        console.log(Data);  
        updatedUserData(Data);
        navi("/userDetail");
     }

    return (<>
    {
        console.log(edit)
    }
        <div className="container-fluid">
            <div className="row" style={{width:'25%',margin:'2%'}}>
                <h2 className="text-primary">Updation Form</h2>
                <form onSubmit={handleSubmit(getUpdatedUserData)}>   
                    <input type="text" hidden {...register("id")} {...setValue("id",edit.id)}/>     
                    <div className="row" style={{marginTop:'20px'}}>
                        <input type="text" {...register("fname")} {...setValue("fname",edit.fname)} className="form-control" placeholder="First name" />
                    </div>
                    <div className="row" style={{marginTop:'20px'}}>
                        <input type="text" {...register("lname")} {...setValue("lname",edit.lname)} className="form-control" placeholder="Last name" />
                    </div>  
                    <div className="row" style={{marginTop:'20px'}}>
                        <input type="text" {...register("mobile")} {...setValue("mobile",edit.mobile)} className="form-control" placeholder="Mobile" />
                    </div>
                    <div className="row" style={{marginTop:'20px'}}>
                        <input type="text" {...register("city")} {...setValue("city",edit.city)} className="form-control" placeholder="City" />
                    </div> 
                    <div className="row" style={{marginTop:'20px'}}>
                        <input type="text" {...register("uname")} {...setValue("uname",edit.uname)} className="form-control" placeholder="Username" />
                    </div>
                    <div className="row" style={{marginTop:'20px'}}>
                        <input type="text" {...register("pass")} {...setValue("pass",edit.pass)} className="form-control" placeholder="Password" />
                    </div>

                    
                    <div style={{marginTop:'20px'}}>
                    <div className="form-check form-check-inline">
                        <input className="form-check-input" type="radio" {...register("gender")} {...setValue("gender",edit.gender)} value="Male" />Male  
                    </div>
                    <div className="form-check form-check-inline">
                        <input className="form-check-input" type="radio" {...register("gender")} {...setValue("gender",edit.gender)} value="Female" />Female  
                    </div>
                    <div className="form-check form-check-inline">
                        <input className="form-check-input" type="radio" {...register("gender")} {...setValue("gender",edit.gender)} value="Transgender" />Transgender 
                    </div>
                    </div>

                    <div style={{marginTop:'20px'}}>
                    <div className="form-check form-check-inline">
                        <input className="form-check-input" type="checkbox" {...register("lang")} {...setValue("lang",edit.lang)} value="Marathi " />Marathi  
                    </div>
                    <div className="form-check form-check-inline">
                        <input className="form-check-input" type="checkbox" {...register("lang")} {...setValue("lang",edit.lang)} value="Hindi " />Hindi   
                    </div>
                    <div className="form-check form-check-inline">
                        <input className="form-check-input" type="checkbox" {...register("lang")} {...setValue("lang",edit.lang)} value="English " />English 
                    </div>
                    </div>

                    <div className="row" style={{marginTop:'20px'}}>
                        <select {...register("course")} {...setValue("course",edit.course)} className="form-select">
                            <option value="NA">Select Course</option>
                            <option value="Python">Python</option>
                            <option value="Java">Java</option>
                            <option value="Angular">Angular</option>
                            <option value="React">React</option>
                        </select>
                    </div>

                    <div className="row" style={{marginTop:'20px'}}>
                        <input type="submit" className="btn btn-success" value="Update"/>
                    </div>    
                </form>
            </div>
        </div>
    </>)
}
export default EditUser;