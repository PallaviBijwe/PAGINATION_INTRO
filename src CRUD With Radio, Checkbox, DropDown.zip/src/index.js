import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter } from 'react-router-dom';
import MyApp from './App';
import './index.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '../node_modules/bootstrap-icons/font/bootstrap-icons.css';

ReactDOM.render(
 <>
    <BrowserRouter>
      <MyApp/>
    </BrowserRouter>
 </>,
  document.getElementById('root')
);

