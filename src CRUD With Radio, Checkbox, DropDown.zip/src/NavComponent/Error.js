
const Error=()=>{
    return (<>
        <h1>This is Error Component</h1>
    </>)
}
export default Error;