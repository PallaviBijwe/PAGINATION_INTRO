
const Home=()=>{
    return (<>
        <h1>This is Home Component</h1>
    </>)
}
export default Home;